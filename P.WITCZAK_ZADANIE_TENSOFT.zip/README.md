# Kręgle
### Program wykorzystuje biblioteki z Laravela
### Załączyłem do repozytorium wyjątkowo cały VENDOR aby ułatwić uruchomienie:
### php app.php
